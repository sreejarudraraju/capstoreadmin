import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Products } from './products';
import { Cart } from './cart';
import { CartTotal } from './cartTotal';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  prod:Observable<Products>;

  constructor(private httpClient:HttpClient) { }

 public showProducts():Observable<Products>
 {
   return this.httpClient.get<Products>("http://localhost:9200/viewProducts");
 }
 
 public addProductsToCart(cart)
 {
  console.log(cart);  
  return this.httpClient.post<Cart>("http://localhost:9200/add/" ,cart)
  console.log("jyfyuf");  
 }

 public showProductsInCart():Observable<Products>
 {
   return this.httpClient.get<Products>("http://localhost:9200/viewCart");
 }
 
 public removeProductFromCart(id):Observable<Products>
 {
   return this.httpClient.delete<Products>("http://localhost:9200/remove/"+id);
 }

 public checkCartValue():Observable<number>
 {
   return this.httpClient.get<number>("http://localhost:9200/checkCart");
 }

}
