import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartPageComponent } from './cart-page/cart-page.component';
import { ProductsPageComponent } from './products-page/products-page.component';
import { MainComponent} from './main/main.component';
const routes: Routes =
 [
{ path:'',redirectTo: '/main', pathMatch: 'full'},
{path: 'main', component:MainComponent},
{path:'cart',
component:CartPageComponent},
{path:'products',
component:ProductsPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
