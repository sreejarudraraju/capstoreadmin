import { Component, OnInit ,Injector, RootRenderer, Injectable} from '@angular/core';
import { ProductService } from '../product.service';
import { Cart } from '../cart';
import { CartTotal } from '../cartTotal';

@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent implements OnInit {

  cartProductsList:Cart;
  cart:Cart;
  msg:String=" ";
  amount:number;
  placeOrder='0';
  c:CartTotal;

  constructor(private productService : ProductService) { 
    this.cart=new Cart();
    this.c=new CartTotal();
  }
  

  ngOnInit() {
    this.getAllCartProducts();
  }
  //imgsrc: string = "./assets/Online-shopping-cart.png";

  getAllCartProducts()
  {
    this.productService.showProductsInCart().subscribe(data=>
    this.cartProductsList=data);
     
  }
  deleteProductFromCart(id)
  {
   this.productService. removeProductFromCart(id).subscribe(data => this.cartProductsList=data);
   console.log("fhuyfy");  
  }

  checkCartValue()
  {
    this.productService.checkCartValue().subscribe(data=>this.amount=data);
    if(this.amount <300)
    {
      alert("Your Cart Value must be atleast Rs.300");
    }
    else
    {
      alert("Proceed to Payment");
    }
    
    
  }

}
