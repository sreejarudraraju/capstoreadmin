package com.cg.capstore.service;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;


import com.cg.capstore.bean.CapCustomer;
import com.cg.capstore.bean.Merchant;

import com.cg.capstore.dao.CustomerDao;
import com.cg.capstore.dao.MerchantDao;
import com.cg.capstore.exception.CapStoreException;


@Service
public class CapStoreServiceImpl implements CapStoreService
{
 @Autowired
 CustomerDao custDao;

 @Autowired
 MerchantDao merDao;

 @Override
 public List<CapCustomer> getCustomers() {
	
	return custDao.findAll();
 }

 @Override
 public List<Merchant> getMerchants() {
	
	return merDao.findAll();
 }




}



