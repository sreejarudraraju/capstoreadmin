package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.bean.CapCustomer;


public interface CustomerDao  extends JpaRepository<CapCustomer,Integer>{

}
