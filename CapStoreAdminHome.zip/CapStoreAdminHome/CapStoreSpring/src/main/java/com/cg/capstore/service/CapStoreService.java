package com.cg.capstore.service;


import java.util.List;


import com.cg.capstore.bean.CapCustomer;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.CapStoreException;


public interface CapStoreService 
{	
	List<CapCustomer> getCustomers();
	
	List<Merchant> getMerchants();
}
