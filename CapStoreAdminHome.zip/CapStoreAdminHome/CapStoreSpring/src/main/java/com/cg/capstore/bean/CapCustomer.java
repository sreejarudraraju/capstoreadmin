package com.cg.capstore.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CapCustomer {
	
 @Id
 int cust_id;
 String u_Name;
 String pwd;
 public int getCust_id() {
	return cust_id;
 }
 public void setCust_Id(int cust_id) {
	this.cust_id = cust_id;
 }

 public String getU_Name() {
	return u_Name;
 }
 public void setU_Name(String u_Name) {
	this.u_Name = u_Name;
 }
 public String getPwd() {
	return pwd;
 }
 public void setPwd(String pwd) {
	this.pwd = pwd;
 }
 @Override
 public String toString() {
	return "Customer [cust_id=" + cust_id + ", u_Name=" + u_Name + ", pwd=" + pwd + "]";
 }


}
