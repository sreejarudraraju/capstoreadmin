package com.cg.capstore.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.bean.CapCustomer;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.CapStoreException;
import com.cg.capstore.service.CapStoreService;


@CrossOrigin(origins="http://localhost:4200")
@RestController
public class CapStoreController 
{

  @Autowired
  CapStoreService service;
  
  @GetMapping(value="/customers")
  List<CapCustomer> getAllCustomers()
  {
	  return service.getCustomers();
  }
  
  @GetMapping(value="/merchants")
  List<Merchant> getAllMerchants()
  {
	  return service.getMerchants();
  }
  
  


}

