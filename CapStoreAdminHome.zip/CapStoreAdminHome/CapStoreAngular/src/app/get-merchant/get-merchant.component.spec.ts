import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetMerchantComponent } from './get-merchant.component';

describe('GetMerchantComponent', () => {
  let component: GetMerchantComponent;
  let fixture: ComponentFixture<GetMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
