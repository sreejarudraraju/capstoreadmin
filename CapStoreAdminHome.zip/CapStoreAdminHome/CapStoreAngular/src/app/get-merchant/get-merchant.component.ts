import { Component, OnInit,Injector, RootRenderer, Injectable } from '@angular/core';
import { MerchantService } from '../merchant.service';
import { Merchant } from '../merchant';

@Component({
  selector: 'app-get-merchant',
  templateUrl: './get-merchant.component.html',
  styleUrls: ['./get-merchant.component.css']
})
export class GetMerchantComponent implements OnInit {

  merchant:Merchant;
  constructor(private merchService:MerchantService) { }

  ngOnInit() {
    this.viewAllMerchants();
  }

  viewAllMerchants()
  {
    console.log("njhi");
     this.merchService.viewMerchants().subscribe(data=>this.merchant=data);
  }

}
