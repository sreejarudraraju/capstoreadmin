import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-merchant',
  templateUrl: './delete-merchant.component.html',
  styleUrls: ['./delete-merchant.component.css']
})
export class DeleteMerchantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
