export class Customer
{
 public cust_id: number;
 public u_Name: string;
 public pwd: String;
 
}