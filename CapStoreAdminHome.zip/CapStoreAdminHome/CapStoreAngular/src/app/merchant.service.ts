import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Merchant } from './merchant';

@Injectable({
  providedIn: 'root'
})
export class MerchantService {

  constructor(private httpClient:HttpClient) {

   }

public viewMerchants(): Observable<Merchant>
 {
 return this.httpClient.get<Merchant>("http://localhost:9090/merchants");
 }
}
