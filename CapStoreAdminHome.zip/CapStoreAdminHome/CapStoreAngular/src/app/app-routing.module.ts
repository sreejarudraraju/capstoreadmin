import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { GetCustomerComponent } from './get-customer/get-customer.component';
import { GetMerchantComponent } from './get-merchant/get-merchant.component';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { DeleteMerchantComponent } from './delete-merchant/delete-merchant.component';
import { CouponsComponent } from './coupons/coupons.component';
import { ChatComponent } from './chat/chat.component';
const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'get-customer', component: GetCustomerComponent },
  { path: 'get-merchant', component: GetMerchantComponent },
  { path: 'add-merchant', component: AddMerchantComponent },
  { path: 'delete-merchant', component: DeleteMerchantComponent },
  { path: 'coupons', component: CouponsComponent},
  { path: 'chat', component: ChatComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
