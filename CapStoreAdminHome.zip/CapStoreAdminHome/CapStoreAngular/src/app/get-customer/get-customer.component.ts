import { Component, OnInit ,Injector, RootRenderer, Injectable} from '@angular/core';
import { CustomerService } from '../customer.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-get-customer',
  templateUrl: './get-customer.component.html',
  styleUrls: ['./get-customer.component.css']
})
export class GetCustomerComponent implements OnInit {

  customer:Customer;
  constructor(private custService:CustomerService) { }

  ngOnInit() {
    this.viewAllCustomers();
  }

  viewAllCustomers()
  {
    console.log("njhi");
     this.custService.viewCustomers().subscribe(data=>this.customer=data);
  }

}
