export class Merchant
{
   public id: number;
   public name: string;
   public email: string;
   public address:String;
   public phoneNo: number;
   
}