export class CartTotal
{
public amount: String;

 
}