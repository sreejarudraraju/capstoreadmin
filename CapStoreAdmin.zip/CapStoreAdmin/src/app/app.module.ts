import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { GetCustomerComponent } from './get-customer/get-customer.component';
import { GetMerchantComponent } from './get-merchant/get-merchant.component';

import { CouponsComponent } from './coupons/coupons.component';
import { AddMerchantComponent } from './add-merchant/add-merchant.component';
import { DeleteMerchantComponent } from './delete-merchant/delete-merchant.component';
import { ChatComponent } from './chat/chat.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    GetCustomerComponent,
    GetMerchantComponent,

    CouponsComponent,

    AddMerchantComponent,

    DeleteMerchantComponent,

    ChatComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
